def classFactory(iface):
    from .mi_plugin import MiPlugin
    return MiPlugin(iface)
