import os
import pandas as pd
from qgis.PyQt.QtCore import QCoreApplication
from qgis.PyQt.QtWidgets import QAction, QDialog, QVBoxLayout, QLabel, QCheckBox, QPushButton, QTextEdit, QScrollArea
from qgis.core import QgsProject, QgsFeature, QgsSymbol, QgsRendererCategory, QgsCategorizedSymbolRenderer, QgsVectorLayer, QgsMapLayer, QgsSpatialIndex
from qgis.utils import Qgis
from PyQt5.QtGui import QColor
from qgis.PyQt.QtWidgets import QAction, QMenu, QToolButton
from PyQt5.QtGui import QIcon
from PyQt5.QtGui import QPixmap, QIcon, QColor
from PyQt5.QtWidgets import QLabel, QAction, QMenu, QToolButton
from PyQt5.QtWidgets import QDialog, QVBoxLayout, QLineEdit, QPushButton, QListWidget, QLabel
from qgis.core import QgsFeatureRequest
from PyQt5.QtWidgets import QFrame
from PyQt5.QtCore import QUrl
from PyQt5.QtGui import QTextCursor
from PyQt5.QtGui import QDesktopServices
from PyQt5.QtWidgets import QTextBrowser, QDialog, QVBoxLayout, QScrollArea
from PyQt5.QtWidgets import QProgressBar
from qgis.core import QgsTask
from qgis.core import QgsApplication
from PyQt5.QtWidgets import QComboBox
from qgis.PyQt.QtWidgets import QMessageBox
from qgis.PyQt.QtWidgets import QProgressDialog

class MiPlugin:
    def __init__(self, iface):
        self.iface = iface
        self.plugin_dir = os.path.dirname(__file__)
        self.toolbar = None
        self.chatbox = ChatboxPlugin(iface)  # Crear una instancia de la ventana de chatbox

        self.data_no_agricola = None
        self.data_na_detalle = None
        self.data_permisos = None
        self.data_recepciones = None
        self.data_regularizaciones = None
        self.data_patentes = None
        self.spatial_index = None
        self.original_renderer = None

        # Inicializar el caché de datos
        self.data_cache = {}  # Añade esta línea para evitar el error

        # Cargar las bases de datos al iniciar el plugin
        # self.load_database()


    def load_database(self, comuna):
        """Carga las bases de datos para la comuna seleccionada y almacena en caché para futuras consultas."""

        # Si ya están en caché, usa los datos guardados
        if comuna in self.data_cache:
            (self.data_permisos, self.data_recepciones, self.data_regularizaciones,
            self.data_no_agricola, self.data_na_detalle, self.data_patentes) = self.data_cache[comuna]
            return

        # Crear un diálogo de progreso
        progress_dialog = QProgressDialog("Cargando datos...", "Cancelar", 0, 6, self.iface.mainWindow())
        progress_dialog.setWindowTitle("Cargando")
        progress_dialog.setWindowModality(Qt.WindowModal)
        progress_dialog.show()

        # Rutas de archivos basadas en la comuna
        comuna_dir = os.path.join(self.plugin_dir, 'BD_COMUNAS', comuna)

        try:
            # Mensajes genéricos de progreso en lugar de detalles específicos
            progress_messages = [
                "Cargando datos...",
                "Estableciendo conexión...",
                "Preparando información...",
                "Procesando registros...",
                "Actualizando sistema...",
                "Finalizando carga..."
            ]

            # Cargar cada archivo y actualizar el progreso con mensajes genéricos
            excel_file_antecedentes = os.path.join(comuna_dir, 'Antecedentes.xlsx')
            self.data_permisos = pd.read_excel(excel_file_antecedentes, sheet_name='Permisos')
            progress_dialog.setLabelText(progress_messages[0])
            progress_dialog.setValue(1)
            progress_dialog.repaint()  # Forzar actualización visual
            if progress_dialog.wasCanceled():
                return

            self.data_recepciones = pd.read_excel(excel_file_antecedentes, sheet_name='Recepciones')
            progress_dialog.setLabelText(progress_messages[1])
            progress_dialog.setValue(2)
            progress_dialog.repaint()  # Forzar actualización visual
            if progress_dialog.wasCanceled():
                return

            self.data_regularizaciones = pd.read_excel(excel_file_antecedentes, sheet_name='Regularizaciones')
            progress_dialog.setLabelText(progress_messages[2])
            progress_dialog.setValue(3)
            progress_dialog.repaint()  # Forzar actualización visual
            if progress_dialog.wasCanceled():
                return

            excel_file_catastro = os.path.join(comuna_dir, 'Catastro_SII.xlsx')
            self.data_no_agricola = pd.read_excel(excel_file_catastro, sheet_name='No_Agricola')
            progress_dialog.setLabelText(progress_messages[3])
            progress_dialog.setValue(4)
            progress_dialog.repaint()  # Forzar actualización visual
            if progress_dialog.wasCanceled():
                return

            self.data_na_detalle = pd.read_excel(excel_file_catastro, sheet_name='NA_Detalle')
            progress_dialog.setLabelText(progress_messages[4])
            progress_dialog.setValue(5)
            progress_dialog.repaint()  # Forzar actualización visual
            if progress_dialog.wasCanceled():
                return

            excel_file_patentes = os.path.join(comuna_dir, 'Patentes_Comerciales.xlsx')
            self.data_patentes = pd.read_excel(excel_file_patentes)
            progress_dialog.setLabelText(progress_messages[5])
            progress_dialog.setValue(6)
            progress_dialog.repaint()  # Forzar actualización visual
            if progress_dialog.wasCanceled():
                return

            # Guardar los datos en caché
            self.data_cache[comuna] = (
                self.data_permisos, self.data_recepciones, self.data_regularizaciones,
                self.data_no_agricola, self.data_na_detalle, self.data_patentes
            )

            self.iface.messageBar().pushMessage("Base de Datos", f"Bases de datos de {comuna} cargadas exitosamente", level=Qgis.Info)

        except Exception as e:
            self.iface.messageBar().pushMessage("Error", f"Error al cargar la base de datos: {str(e)}", level=Qgis.Critical)

        finally:
            progress_dialog.close()


   
    def unload(self):
        """Elimina la barra de herramientas cuando se desactiva el plugin."""
        if self.toolbar:
            del self.toolbar
    def initGui(self):
        self.toolbar = self.iface.addToolBar("GeoInspector")



        
        # Crear un QLabel para el logo y ajustarlo al tamaño deseado
        logo_label = QLabel()
        logo_path = os.path.join(self.plugin_dir, "logo_sin.png")
        pixmap = QPixmap(logo_path).scaled(150, 30)  # Ajusta el tamaño según tus preferencias
        logo_label.setPixmap(pixmap)

        # Añadir el QLabel como widget en la barra de herramientas
        self.toolbar.addWidget(logo_label)

        # Añadir un separador
        self.toolbar.addSeparator()

        self.combo_comuna = QComboBox()
        self.combo_comuna.addItem("-")  # Añadir el valor por defecto "-"
        self.combo_comuna.setToolTip("Selecciona la comuna")
        self.toolbar.addWidget(self.combo_comuna)

        # Cargar nombres de comunas en el combo box
        self.load_comunas()

        # Conectar el cambio de selección del combo box
        self.combo_comuna.currentIndexChanged.connect(self.on_comuna_selected)

        # Añadir un separador
        self.toolbar.addSeparator()

        # Añadir el botón "Buscar" a la barra de herramientas
        icon_path_buscar = os.path.join(self.plugin_dir, "icons", "BUSCAR_BOT.png")
        self.action_buscar = QAction(QIcon(icon_path_buscar), "", self.iface.mainWindow())
        self.action_buscar.setToolTip("Buscar predio por dirección o ROL")
        self.action_buscar.triggered.connect(self.abrir_ventana_busqueda)
        self.toolbar.addAction(self.action_buscar)

        # Añadir un separador
        self.toolbar.addSeparator()

        # Acción para consultar información del rol
        icon_path_consultar = os.path.join(self.plugin_dir, "icons", "BUS_SII.png")
        self.action_consultar = QAction(QIcon(icon_path_consultar), "", self.iface.mainWindow())
        self.action_consultar.setToolTip("Consultar informacion de Catastro SII")
        self.action_consultar.triggered.connect(self.consultar_rol)
        self.toolbar.addAction(self.action_consultar)

        # Acción para consultar antecedentes municipales
        icon_path_permisos = os.path.join(self.plugin_dir, "icons", "BUS_MUN.png")
        self.action_consultar_permisos = QAction(QIcon(icon_path_permisos), "", self.iface.mainWindow())
        self.action_consultar_permisos.setToolTip("Consultar información de Antecedente Municipal")
        self.action_consultar_permisos.triggered.connect(self.consultar_antecedente_municipal)
        self.toolbar.addAction(self.action_consultar_permisos)

        # Acción para consultar patentes comerciales
        icon_path_patentes_info = os.path.join(self.plugin_dir, "icons", "BUS_PAT.png")
        self.boton_patentes_info = QAction(QIcon(icon_path_patentes_info), "", self.iface.mainWindow())
        self.boton_patentes_info.setToolTip("Consultar inforamción de Patentes Comerciales")
        self.boton_patentes_info.triggered.connect(self.consultar_patente_rol_seleccionado)
        self.toolbar.addAction(self.boton_patentes_info)

        # Añadir un separador
        self.toolbar.addSeparator()


        # En initGui, reemplaza el menú de "Estudio" con un botón que abra la ventana de descripción de estudios
        self.action_estudio = QAction("Estudio", self.iface.mainWindow())
        self.action_estudio.triggered.connect(self.abrir_ventana_estudio)
        self.toolbar.addAction(self.action_estudio)

        # Añadir un separador
        self.toolbar.addSeparator()

        # Acción para el análisis de destinos
        icon_path_analizar_destinos = os.path.join(self.plugin_dir, "icons", "FIL_DATOS.png")
        self.action_analizar_destinos = QAction(QIcon(icon_path_analizar_destinos), "", self.iface.mainWindow())
        self.action_analizar_destinos.setToolTip("Filtros Dinámicos entre Destinos y Antecedentes")
        self.action_analizar_destinos.triggered.connect(self.abrir_dialogo_destinos)
        self.toolbar.addAction(self.action_analizar_destinos)

        # Añadir un separador
        self.toolbar.addSeparator()

        # Botón para ejecutar el análisis de antecedentes
        icon_path_antecedentes = os.path.join(self.plugin_dir, "icons", "PINT_MUN.png")
        self.action_analizar_antecedentes = QAction(QIcon(icon_path_antecedentes), "", self.iface.mainWindow())
        self.action_analizar_antecedentes.setToolTip("Pintar predios con Antecedentes Municipales (Área visible en pantalla)")
        self.action_analizar_antecedentes.triggered.connect(self.analisis_Antecedentes)
        self.toolbar.addAction(self.action_analizar_antecedentes)

        # Agregar botón en la interfaz de usuario
        icon_path_detectar_patentes = os.path.join(self.plugin_dir, "icons", "PINT_PAT.png")
        self.boton_patentes = QAction(QIcon(icon_path_detectar_patentes), "", self.iface.mainWindow())
        self.boton_patentes.setToolTip("Pintar predios con Patentes Comerciales (Área visible en pantalla)")
        self.boton_patentes.triggered.connect(self.detectar_roles_con_patente_comercial)
        self.toolbar.addAction(self.boton_patentes)

        # Añadir un separador
        self.toolbar.addSeparator()

        # Acción para soltar resultados y restaurar colores originales
        self.action_resetear = QAction("Soltar Resultados", self.iface.mainWindow())
        self.action_resetear.triggered.connect(self.soltar_resultados)
        self.toolbar.addAction(self.action_resetear)
        self.action_resetear.setIcon(QIcon(os.path.join(self.plugin_dir, "icon_reset.png")))
        self.action_resetear.setToolTip("Restablecer gráfica de Predios")


                # Añadir un separador
        self.toolbar.addSeparator()

        
        # Crear el botón de chatbox y añadirlo a la barra de herramientas del plugin
        icon_path_chatbox = os.path.join(self.plugin_dir, "icons", "icon_chatbox.png")  # Asegúrate de tener un ícono para el chatbox
        self.chatbox_action = QAction(QIcon(icon_path_chatbox), "Abrir Chatbox de Ayuda", self.iface.mainWindow())
        self.chatbox_action.triggered.connect(self.toggle_chatbox)
        self.chatbox_action.setToolTip("Abrir Chatbox de Ayuda")

        # Añadir el botón de chatbox a la barra de herramientas personalizada
        self.toolbar.addAction(self.chatbox_action)

    def toggle_chatbox(self):
        # Alternar visibilidad del chatbox
        self.chatbox.setVisible(not self.chatbox.isVisible())


 #SELECCION DE COMUNA, DEBE TENER EL NOMBRE DE LA COMUNA EN LA CARPETA DE DB

    def load_comunas(self):
        bd_comunas_dir = os.path.join(self.plugin_dir, 'BD_COMUNAS')
        if os.path.exists(bd_comunas_dir):
            for comuna in os.listdir(bd_comunas_dir):
                if os.path.isdir(os.path.join(bd_comunas_dir, comuna)):
                    self.combo_comuna.addItem(comuna)

    def on_comuna_selected(self):
        comuna = self.combo_comuna.currentText()
        
        # Evitar cargar datos si la comuna es "-"
        if comuna == "-":
            self.iface.messageBar().pushMessage("Atención", "Por favor, selecciona una comuna válida.", level=Qgis.Warning)
            return
        
        # Cargar la base de datos para la comuna seleccionada
        self.load_database(comuna)

    def detectar_roles_con_patente_comercial(self):
        """Pinta en el mapa todos los predios cuyo ROL_SII coincida con algún ROL en la base de datos de patentes comerciales."""

        # Obtener la capa activa y verificar su tipo
        layer = self.iface.activeLayer()
        if not layer or layer.type() != QgsMapLayer.VectorLayer:
            self.iface.messageBar().pushMessage("Error", "La capa activa no es válida o no es vectorial", level=Qgis.Critical)
            return

        if self.original_renderer is None:
            self.original_renderer = layer.renderer().clone()

        if not self.spatial_index:
            self.spatial_index = QgsSpatialIndex(layer.getFeatures())

        # Crear un conjunto de ROLs presentes en la base de datos de patentes comerciales para búsqueda rápida
        roles_con_patente = set(self.data_patentes['ROL'].dropna().unique())

        # Identificar los predios visibles en el mapa
        extent = self.iface.mapCanvas().extent()
        ids_visibles = self.spatial_index.intersects(extent)

        # Asignar un color específico para todos los ROL coincidentes con patente comercial
        color_patente = QColor(0, 255, 0, 150)  # Color verde con transparencia
        categories = []

        # Iterar sobre los predios visibles y aplicar color si el ROL coincide
        for fid in ids_visibles:
            feature = layer.getFeature(fid)
            rol = feature["ROL_SII"]

            # Verificar si el ROL del predio está en la base de datos de patentes comerciales
            if rol in roles_con_patente:
                symbol = QgsSymbol.defaultSymbol(layer.geometryType())
                symbol.setColor(color_patente)
                category = QgsRendererCategory(rol, symbol, str(rol))
                categories.append(category)

        # Aplicar el renderer categorizado con el color específico a la capa
        renderer = QgsCategorizedSymbolRenderer("ROL_SII", categories)
        layer.setRenderer(renderer)
        layer.triggerRepaint()

        self.iface.messageBar().pushMessage("Análisis de Patentes Comerciales", "Filtro aplicado y color asignado a los ROL con patente comercial.", level=Qgis.Info)

    
    def abrir_ventana_busqueda(self):

        """Abre una ventana para buscar predios por ROL o Dirección."""
        dialogo = QDialog(self.iface.mainWindow())
        dialogo.setWindowTitle("Buscar Predio")
        layout = QVBoxLayout()

        # Campo para ROL
        self.campo_rol = QLineEdit()
        self.campo_rol.setPlaceholderText("Ingrese ROL (ej. 123456)")
        layout.addWidget(QLabel("ROL:"))
        layout.addWidget(self.campo_rol)

        # Campo para Dirección con lista de sugerencias
        self.campo_direccion = QLineEdit()
        self.campo_direccion.setPlaceholderText("Ingrese Dirección (ej. Avenida La Estrella)")
        layout.addWidget(QLabel("Dirección:"))
        layout.addWidget(self.campo_direccion)

        # Lista para mostrar sugerencias de dirección
        self.lista_sugerencias = QListWidget()
        layout.addWidget(self.lista_sugerencias)

        # Conectar el campo de dirección con la función de sugerencias
        self.campo_direccion.textChanged.connect(self.mostrar_sugerencias_direccion)

        # Botón para ejecutar la búsqueda
        boton_buscar = QPushButton("Buscar")
        boton_buscar.clicked.connect(self.ejecutar_busqueda)
        layout.addWidget(boton_buscar)

        dialogo.setLayout(layout)
        dialogo.exec_()

    def mostrar_sugerencias_direccion(self):
        """Muestra una lista de sugerencias basadas en la entrada de dirección."""
        texto = self.campo_direccion.text().strip().upper()
        self.lista_sugerencias.clear()
    
        if not texto:
            return

        # Filtrar las direcciones en la base de datos que contienen el texto ingresado
        coincidencias = self.data_no_agricola[self.data_no_agricola['Direccion'].str.contains(texto, case=False, na=False)]
        for direccion in coincidencias['Direccion'].unique():
            self.lista_sugerencias.addItem(direccion)

        # Conectar las sugerencias seleccionadas para completar el campo de dirección
        self.lista_sugerencias.itemClicked.connect(self.completar_direccion)

    def completar_direccion(self, item):
        """Completa el campo de dirección con la selección de la lista sin interferir con el texto actual."""
        self.campo_direccion.blockSignals(True)  # Evitar que se disparen señales mientras se actualiza el texto
        self.campo_direccion.setText(item.text())
        self.campo_direccion.blockSignals(False)





    def ejecutar_busqueda(self):
        """Ejecuta la búsqueda en función del ROL o Dirección ingresados."""
        rol = self.campo_rol.text().strip()
        direccion = self.campo_direccion.text().strip()

        if rol:
            # Buscar directamente en la capa activa por ROL
            self.buscar_por_rol(rol)
        elif direccion:
            # Buscar en la base de datos y luego en la capa por Dirección
            self.buscar_por_direccion(direccion)
        else:
            self.iface.messageBar().pushMessage("Error", "Por favor ingrese un ROL o una Dirección para buscar.", level=Qgis.Warning)

    def buscar_por_rol(self, rol):
        """Busca un predio en la capa activa según el ROL y centra el mapa en él."""
        layer = self.iface.activeLayer()
        if not layer:
            self.iface.messageBar().pushMessage("Error", "No hay una capa activa.", level=Qgis.Critical)
            return

        # Buscar el ROL en la capa activa
        expression = f"\"ROL_SII\" = '{rol}'"
        features = layer.getFeatures(QgsFeatureRequest().setFilterExpression(expression))
        found = False

        for feature in features:
            self.iface.mapCanvas().setExtent(feature.geometry().boundingBox())
            layer.selectByIds([feature.id()])
            found = True
            break

        if not found:
            self.iface.messageBar().pushMessage("Error", "ROL no encontrado en la capa activa.", level=Qgis.Warning)

    def buscar_por_direccion(self, direccion):
        """Busca coincidencias en la base de datos de direcciones y centra el mapa en los resultados."""
        # Filtrar las coincidencias de dirección en la base de datos
        coincidencias = self.data_no_agricola[self.data_no_agricola['Direccion'].str.contains(direccion, case=False, na=False)]
    
        if coincidencias.empty:
            self.iface.messageBar().pushMessage("Error", "Dirección no encontrada en la base de datos.", level=Qgis.Warning)
            return

        # Obtener el primer ROL de las coincidencias para buscar en la capa
        rol = coincidencias['ROL'].iloc[0]
        self.buscar_por_rol(rol)


    def obtener_color_por_anio(self, anio):



        """Devuelve un color basado en la antigüedad de la construcción con transparencia."""
        anio_actual = 2024
        opacidad = 150

        if pd.isnull(anio) or anio == 0:
            return None

        try:
            anio = int(anio)
        except (ValueError, TypeError):
            return None

        antiguedad = anio_actual - anio

        if antiguedad <= 10:
            return QColor(0, 0, 255, opacidad)  # Azul
        elif antiguedad <= 20:
            return QColor(173, 216, 230, opacidad)  # Celeste
        elif antiguedad <= 30:
            return QColor(255, 255, 0, opacidad)  # Amarillo
        elif antiguedad > 40:
            return QColor(255, 0, 0, opacidad)  # Rojo
        else:
            return None
    def consultar_antecedente_municipal(self):
        """Consulta y muestra los antecedentes municipales asociados a un rol."""

        layer = self.iface.activeLayer()
        if not layer:
            self.iface.messageBar().pushMessage("Error", "No hay capa activa", level=Qgis.Critical)
            return

        features = layer.selectedFeatures()
        if len(features) == 0:
            self.iface.messageBar().pushMessage("Error", "No hay predios seleccionados", level=Qgis.Critical)
            return

        rol = features[0]["ROL_SII"]

        # Consultar en las tres hojas
        permisos = self.data_permisos[self.data_permisos['ROL'] == rol]
        recepciones = self.data_recepciones[self.data_recepciones['ROL'] == rol]
        regularizaciones = self.data_regularizaciones[self.data_regularizaciones['ROL'] == rol]

        # Combinar los resultados en un solo DataFrame
        resultados = pd.concat([permisos, recepciones, regularizaciones])

        if resultados.empty:
            self.iface.messageBar().pushMessage("Sin resultados", "No se encontraron antecedentes para el rol seleccionado", level=Qgis.Warning)
            return

        # Mostrar todos los resultados combinados
        self.mostrar_info_permisos(resultados)





    def mostrar_info_permisos(self, permisos):


        """Muestra la información de los permisos municipales en un cuadro de diálogo con scroll y texto copiable."""
        dialog = QDialog()
        dialog.setWindowTitle("Antecedentes Municipales")
        layout = QVBoxLayout()

        # Área de desplazamiento para ver todos los resultados
        scroll_area = QScrollArea(dialog)
        scroll_area.setWidgetResizable(True)

        # Usar QTextBrowser en lugar de QTextEdit para habilitar enlaces clickeables
        text_widget = QTextBrowser()
        text_widget.setOpenLinks(False)  # Deshabilitar la navegación interna

        # Conectar los clics en los enlaces para abrir en navegador sin cambiar el contenido
        def handle_link_click(url):
            QDesktopServices.openUrl(url)
        
        text_widget.anchorClicked.connect(handle_link_click)

        # Construir el texto con la información de los permisos
        detalles_texto = "<html><body style='font-family: Arial; font-size: 12px;'>"
        for _, permiso in permisos.iterrows():
            detalles = (
                f"<b>Propietario:</b> {permiso['PROPIETARIO']}<br>"
                f"<b>Dirección:</b> {permiso['DIRECCION']}<br>"
                f"<b>Resolución:</b> {permiso['Nº RES.']}<br>"
                f"<b>Tipo:</b> {permiso['TIPO']}<br>"
                f"<b>Fecha:</b> {permiso['FECHA']}<br>"
            )

            # Verificar si hay un link disponible y hacerlo clickeable
            link = permiso['LINK']
            if pd.notna(link) and link != "nan":
                detalles += f'<b>Link:</b> <a href="{link}">Enlace</a><br>'
            else:
                detalles += "<b>Link:</b> No disponible<br>"

            detalles += "<hr style='border: 1px solid #ccc; margin: 10px 0;'>"
            detalles_texto += detalles

        detalles_texto += "</body></html>"
        text_widget.setHtml(detalles_texto)

        # Agregar el widget de texto al área de scroll
        scroll_area.setWidget(text_widget)

        # Agregar el área de scroll al layout
        layout.addWidget(scroll_area)
        dialog.setLayout(layout)
        dialog.resize(600, 500)  # Ajustar el tamaño inicial del diálogo
        dialog.exec_()


    def mostrar_info_patentes(self, rol_seleccionado):


        """Muestra la información de las patentes comerciales del ROL seleccionado en un cuadro de diálogo con scroll y texto copiable."""
        dialog = QDialog()
        dialog.setWindowTitle(f"Información de Patentes Comerciales - ROL: {rol_seleccionado}")
        layout = QVBoxLayout()

        # Filtrar la base de datos de patentes para obtener solo la información del ROL seleccionado
        patentes_filtradas = self.data_patentes[self.data_patentes['ROL'] == rol_seleccionado]

        # Verificar si hay patentes para el ROL seleccionado
        if patentes_filtradas.empty:
            self.iface.messageBar().pushMessage("Información", "No hay patentes comerciales para el ROL seleccionado.", level=Qgis.Warning)
            return

        # Área de desplazamiento para ver todos los resultados
        scroll_area = QScrollArea(dialog)
        scroll_area.setWidgetResizable(True)

        # Widget de texto para mostrar todos los detalles
        text_widget = QTextEdit()
        text_widget.setReadOnly(True)

        # Construir el texto con la información de las patentes
        detalles_texto = "<html><body style='font-family: Arial; font-size: 12px;'>"
        for _, patente in patentes_filtradas.iterrows():
            rut_completo = f"{patente['RUT']}-{patente['DV']}"
            detalles = (
                f"<b>Nombre:</b> {patente['NOMBRE']}<br>"
                f"<b>RUT:</b> {rut_completo}<br>"
                f"<b>Año:</b> {patente['AÑO']}<br>"
                f"<b>Semestre:</b> {patente['SEMESTRE']}<br>"
                f"<b>Rubro:</b> {patente['RUBRO']}<br>"
                f"<b>Dirección:</b> {patente['DIRECCIÓN']}<br>"
            )
            detalles += "<hr style='border: 1px solid #ccc; margin: 10px 0;'>"
            detalles_texto += detalles

        detalles_texto += "</body></html>"
        text_widget.setHtml(detalles_texto)

        # Agregar el widget de texto al área de scroll
        scroll_area.setWidget(text_widget)
        layout.addWidget(scroll_area)
        dialog.setLayout(layout)
        dialog.resize(600, 500)
        dialog.exec_()

    def consultar_patente_rol_seleccionado(self):


        layer = self.iface.activeLayer()
        if not layer or layer.selectedFeatureCount() == 0:
            self.iface.messageBar().pushMessage("Error", "Debe seleccionar un predio en el mapa", level=Qgis.Warning)
            return

        # Obtener el ROL del primer predio seleccionado
        feature = layer.selectedFeatures()[0]  # Tomamos el primer predio seleccionado
        rol_seleccionado = feature["ROL_SII"]  # Asegúrate de que este es el campo que contiene el ROL en tu capa

        # Llamar a la función de mostrar información de patentes con el ROL seleccionado
        self.mostrar_info_patentes(rol_seleccionado)


    def consultar_rol(self):


        """Consulta y muestra la información del rol seleccionado en la capa activa."""
        layer = self.iface.activeLayer()
        if not layer:
            self.iface.messageBar().pushMessage("Error", "No hay capa activa", level=Qgis.Critical)
            return

        features = layer.selectedFeatures()
        if len(features) == 0:
            self.iface.messageBar().pushMessage("Error", "No hay predios seleccionados", level=Qgis.Critical)
            return

        rol = features[0]["ROL_SII"]

        try:
            info_no_agricola = self.data_no_agricola[self.data_no_agricola['ROL'] == rol].iloc[0]
            detalles_construcciones = self.data_na_detalle[self.data_na_detalle['ROL'] == rol]
            self.mostrar_info_rol(info_no_agricola, detalles_construcciones)
        except IndexError:
            self.iface.messageBar().pushMessage("Error", "No se encontró información para el rol seleccionado", level=Qgis.Warning)

    def mostrar_info_rol(self, info_no_agricola, detalles_construcciones):



        """Muestra un diálogo con la información detallada del rol seleccionado."""
        dialog = QDialog()
        dialog.setWindowTitle("Información del Rol")
        layout = QVBoxLayout()

        avaluo_total = f"{info_no_agricola['Avaluo Total']:,}".replace(",", ".")
        detalles_generales = (
            f"Dirección: {info_no_agricola['Direccion']}\n"
            f"Avaluo Total: {avaluo_total} CLP\n"
            f"Contribuciones: {info_no_agricola['Contribuciones']} CLP\n"
            f"Destino: {info_no_agricola['Destino']}\n"
            f"Terreno: {info_no_agricola['m² Terreno']} m²\n"
        )
        layout.addWidget(QLabel(detalles_generales))

        detalles_construccion_text = "Construcciones:\n"
        for _, row in detalles_construcciones.iterrows():
            detalles_construccion_text += (
                f"- Línea de Construcción: {row['Linea Construccion']}, "
                f"Destino: {row['Destino']}, Clase: {row['Clase']}, "
                f"Superficie: {row['m²']} m², "
                f"Año Construcción: {row['Año Construccion']}\n"
            )

        layout.addWidget(QLabel(detalles_construccion_text))
        dialog.setLayout(layout)
        dialog.exec_()




    def pintar_avaluo(self):


        """Resaltar predios con Avaluo Total mayor o igual a un valor específico."""
        layer = self.iface.activeLayer()
        if not layer:
            self.iface.messageBar().pushMessage("Error", "No hay capa activa", level=Qgis.Critical)
            return

        if layer.type() != QgsMapLayer.VectorLayer:
            self.iface.messageBar().pushMessage("Error", "La capa activa no es vectorial", level=Qgis.Critical)
            return

        if self.original_renderer is None:
            self.original_renderer = layer.renderer().clone()

        if not self.spatial_index:
            self.spatial_index = QgsSpatialIndex(layer.getFeatures())

        extent = self.iface.mapCanvas().extent()
        ids_visibles = self.spatial_index.intersects(extent)

        categories = []
        for fid in ids_visibles:
            feature = layer.getFeature(fid)
            rol = feature["ROL_SII"]
            info_no_agricola = self.data_no_agricola[self.data_no_agricola['ROL'] == rol]
            if not info_no_agricola.empty and info_no_agricola["Avaluo Total"].values[0] >= 56846995:
                symbol = QgsSymbol.defaultSymbol(layer.geometryType())
                symbol.setColor(QColor(255, 165, 0, 150))  # Naranja con transparencia
                category = QgsRendererCategory(rol, symbol, str(rol))
                categories.append(category)

        renderer = QgsCategorizedSymbolRenderer("ROL_SII", categories)
        layer.setRenderer(renderer)
        layer.triggerRepaint()

        self.iface.messageBar().pushMessage("Avaluo", "Predios con Avaluo pintados", level=Qgis.Info)

    def activar_detector(self):
        """Aplicar simbología basada en la antigüedad de las construcciones."""
        layer = self.iface.activeLayer()

        if not layer:
            self.iface.messageBar().pushMessage("Error", "No hay capa activa", level=Qgis.Critical)
            return

        if layer.type() != QgsMapLayer.VectorLayer:
            self.iface.messageBar().pushMessage("Error", "La capa activa no es vectorial", level=Qgis.Critical)
            return

        if self.original_renderer is None:
            self.original_renderer = layer.renderer().clone()

        if not self.spatial_index:
            self.spatial_index = QgsSpatialIndex(layer.getFeatures())

        extent = self.iface.mapCanvas().extent()
        ids_visibles = self.spatial_index.intersects(extent)

        categories = []
        for fid in ids_visibles:
            feature = layer.getFeature(fid)
            rol = feature["ROL_SII"]
            info_construccion = self.data_na_detalle[self.data_na_detalle['ROL'] == rol]
            if not info_construccion.empty:
                max_anio = info_construccion["Año Construccion"].max()
                color = self.obtener_color_por_anio(max_anio)

                if color is not None:
                    symbol = QgsSymbol.defaultSymbol(layer.geometryType())
                    symbol.setColor(color)
                    category = QgsRendererCategory(rol, symbol, str(rol))
                    categories.append(category)

        renderer = QgsCategorizedSymbolRenderer("ROL_SII", categories)
        layer.setRenderer(renderer)
        layer.triggerRepaint()

        self.iface.messageBar().pushMessage("Detector", "Detector de antigüedad activado", level=Qgis.Info)




    def soltar_resultados(self):
        """Restaurar el estilo original de la capa."""
        layer = self.iface.activeLayer()

        if not layer:
            self.iface.messageBar().pushMessage("Error", "No hay capa activa", level=Qgis.Critical)
            return

        if self.original_renderer:
            layer.setRenderer(self.original_renderer)
            self.original_renderer = None
            layer.triggerRepaint()
            self.iface.messageBar().pushMessage("Restauración", "Estilo original restaurado.", level=Qgis.Info)
        else:
            self.iface.messageBar().pushMessage("Error", "No hay estilo original guardado para restaurar.", level=Qgis.Warning)




    def abrir_dialogo_destinos(self):


        """Abre un diálogo para seleccionar destinos y filtrar predios en base a esos destinos, incluyendo antecedentes municipales."""
        self.dialogo_destinos = QDialog()
        self.dialogo_destinos.setWindowTitle("Análisis de Destinos y Antecedentes Municipales")
        layout = QVBoxLayout()

        # Checkboxes para destinos
        self.destinos = {
            "C": "Comercio",
            "D": "Deporte y Recreación",
            "E": "Educación y Cultura",
            "G": "Hotel - Motel",
            "H": "Habitación",
            "I": "Industria",
            "L": "Bodega y Almacenaje",
            "M": "Minería",
            "O": "Oficina",
            "P": "Administración Pública y Defensa",
            "Q": "Culto",
            "S": "Salud",
            "T": "Transporte y Telecomunicaciones",
            "V": "Otros no considerados",
            "W": "Sitio Eriazo",
            "Z": "Estacionamiento",
            "K": "Bien Común"
        }

        self.checkboxes_destinos = {}
        for codigo, nombre in self.destinos.items():
            checkbox = QCheckBox(f"{nombre} ({codigo})")
            layout.addWidget(checkbox)
            self.checkboxes_destinos[codigo] = checkbox

        # Agregar un separador antes de Antecedentes Municipales
        separador = QFrame()
        separador.setFrameShape(QFrame.HLine)
        separador.setFrameShadow(QFrame.Sunken)
        layout.addWidget(separador)

        # Checkbox para Antecedentes Municipales
        self.checkbox_antecedentes = QCheckBox("Antecedentes Municipales")
        layout.addWidget(self.checkbox_antecedentes)

        # Agregar un separador antes de Antecedentes Municipales
        separador = QFrame()
        separador.setFrameShape(QFrame.HLine)
        separador.setFrameShadow(QFrame.Sunken)
        layout.addWidget(separador)

        # Checkbox para Patentes Comerciales
        self.checkbox_patentes = QCheckBox("Patentes Comerciales")
        layout.addWidget(self.checkbox_patentes)

        # Botón para ejecutar el análisis
        boton_filtrar = QPushButton("Filtrar")
        boton_filtrar.clicked.connect(self.filtrar_por_destinos)
        layout.addWidget(boton_filtrar)

        self.dialogo_destinos.setLayout(layout)
        self.dialogo_destinos.exec_()

    def filtrar_por_destinos(self):
        """Filtra los predios en base a los destinos seleccionados y, opcionalmente, si tienen antecedentes municipales o patentes comerciales."""
        layer = self.iface.activeLayer()

        if not layer:
            self.iface.messageBar().pushMessage("Error", "No hay capa activa", level=Qgis.Critical)
            return

        if layer.type() != QgsMapLayer.VectorLayer:
            self.iface.messageBar().pushMessage("Error", "La capa activa no es vectorial", level=Qgis.Critical)
            return

        destinos_seleccionados = [dest for dest, checkbox in self.checkboxes_destinos.items() if checkbox.isChecked()]
        filtrar_antecedentes = self.checkbox_antecedentes.isChecked()
        filtrar_patentes = self.checkbox_patentes.isChecked()

        if not destinos_seleccionados and not filtrar_antecedentes and not filtrar_patentes:
            self.iface.messageBar().pushMessage("Error", "No se ha seleccionado ningún filtro", level=Qgis.Warning)
            return

        if self.original_renderer is None:
            self.original_renderer = layer.renderer().clone()

        if not self.spatial_index:
            self.spatial_index = QgsSpatialIndex(layer.getFeatures())

        extent = self.iface.mapCanvas().extent()
        ids_visibles = self.spatial_index.intersects(extent)

        color_antecedentes = QColor(0, 128, 255, 150)
        color_patentes = QColor(0, 255, 0, 150)
        colores_destinos = {
            "C": QColor(0, 0, 255, 150),
            "D": QColor(0, 128, 0, 150),
            "E": QColor(255, 215, 0, 150),
            "G": QColor(255, 105, 180, 150),
            "H": QColor(255, 165, 0, 150),
            "I": QColor(128, 0, 0, 150),
            "L": QColor(255, 0, 255, 150),
            "M": QColor(0, 255, 0, 150),
            "O": QColor(75, 0, 130, 150),
            "P": QColor(255, 0, 0, 150),
            "Q": QColor(0, 255, 255, 150),
            "S": QColor(255, 69, 0, 150),
            "T": QColor(255, 255, 0, 150),
            "V": QColor(169, 169, 169, 150),
            "W": QColor(0, 0, 0, 150),
            "Z": QColor(192, 192, 192, 150),
            "K": QColor(139, 69, 19, 150)
        }

        roles_con_antecedentes = set(self.data_permisos['ROL'].dropna().unique()) if filtrar_antecedentes else set()
        roles_con_patentes = set(self.data_patentes['ROL'].dropna().unique()) if filtrar_patentes else set()

        # Convertir data_no_agricola en un diccionario para acceso rápido
        data_no_agricola_dict = {rol: destino for rol, destino in zip(self.data_no_agricola['ROL'], self.data_no_agricola['Destino'])}

        # Obtener todas las características visibles en un solo bloque
        visible_features = {feat.id(): feat for feat in layer.getFeatures(QgsFeatureRequest().setFilterFids(ids_visibles))}

        categories = []

        for fid, feature in visible_features.items():
            rol = feature["ROL_SII"]
            destino_actual = data_no_agricola_dict.get(rol)

            # Determinar si el predio cumple con los destinos seleccionados
            cumple_destino = destino_actual in destinos_seleccionados if destino_actual and destinos_seleccionados else True
            cumple_antecedentes = rol in roles_con_antecedentes if filtrar_antecedentes else True
            cumple_patentes = rol in roles_con_patentes if filtrar_patentes else True

            if cumple_destino and cumple_antecedentes and cumple_patentes:
                symbol = QgsSymbol.defaultSymbol(layer.geometryType())
                
                # Prioridad de colores: antecedentes, luego patentes, luego destino específico
                if filtrar_antecedentes and cumple_antecedentes:
                    symbol.setColor(color_antecedentes)
                elif filtrar_patentes and cumple_patentes:
                    symbol.setColor(color_patentes)
                else:
                    # Color específico para el destino
                    color = colores_destinos.get(destino_actual, QColor(128, 128, 128, 150))
                    symbol.setColor(color)

                categories.append(QgsRendererCategory(rol, symbol, str(rol)))

        renderer = QgsCategorizedSymbolRenderer("ROL_SII", categories)
        layer.setRenderer(renderer)
        layer.triggerRepaint()

        self.iface.messageBar().pushMessage("Filtros Dinámicos", "Predios filtrados según destinos, antecedentes y patentes seleccionados", level=Qgis.Info)
        self.dialogo_destinos.close()



    def analisis_Antecedentes(self):

        """Pinta en el mapa todos los predios cuyo ROL_SII coincida con algún ROL en cualquiera de las bases de datos de antecedentes."""
    
        # Obtener la capa activa y verificar su tipo
        layer = self.iface.activeLayer()
        if not layer or layer.type() != QgsMapLayer.VectorLayer:
            self.iface.messageBar().pushMessage("Error", "La capa activa no es válida o no es vectorial", level=Qgis.Critical)
            return

        if self.original_renderer is None:
            self.original_renderer = layer.renderer().clone()

        if not self.spatial_index:
            self.spatial_index = QgsSpatialIndex(layer.getFeatures())

        # Crear un conjunto de ROLs presentes en todas las bases de datos para búsqueda rápida
        roles_en_base_datos = set(self.data_permisos['ROL'].dropna().unique())
        roles_en_base_datos.update(self.data_recepciones['ROL'].dropna().unique())
        roles_en_base_datos.update(self.data_regularizaciones['ROL'].dropna().unique())

        # Identificar los predios visibles en el mapa
        extent = self.iface.mapCanvas().extent()
        ids_visibles = self.spatial_index.intersects(extent)

        # Asignar un color común con opacidad para todos los ROL coincidentes
        color_unico = QColor(0, 128, 255, 150)  # Color azul con transparencia
        categories = []

        # Iterar sobre los predios visibles y aplicar color si el ROL coincide
        for fid in ids_visibles:
            feature = layer.getFeature(fid)
            rol = feature["ROL_SII"]

            # Verificar si el ROL del predio está en el conjunto de roles de las tres bases de datos
            if rol in roles_en_base_datos:
                symbol = QgsSymbol.defaultSymbol(layer.geometryType())
                symbol.setColor(color_unico)
                category = QgsRendererCategory(rol, symbol, str(rol))
                categories.append(category)

        # Aplicar el renderer categorizado con el color único a la capa
        renderer = QgsCategorizedSymbolRenderer("ROL_SII", categories)
        layer.setRenderer(renderer)
        layer.triggerRepaint()

        self.iface.messageBar().pushMessage("Análisis de Antecedentes", "Filtro aplicado y color único asignado a los ROL coincidentes.", level=Qgis.Info)



    def abrir_ventana_estudio(self):
        """Abre una ventana para seleccionar y ejecutar estudios específicos con una descripción."""
        dialog = QDialog(self.iface.mainWindow())
        dialog.setWindowTitle("Estudios y Análisis")
        layout = QVBoxLayout()

        # Descripción y botón para el análisis de construcciones
        layout.addWidget(QLabel("<b>Análisis de Construcciones</b>"))
        layout.addWidget(QLabel("Genera un mapa visual de construcciones, coloreado por la antigüedad de la última línea de construcción.\n"
                                "Colores:\n"
                                " - Azul: hasta 10 años\n"
                                " - Celeste: hasta 20 años\n"
                                " - Amarillo: hasta 30 años\n"
                                " - Rojo: más de 40 años\n"))
        boton_construcciones = QPushButton("Ejecutar Análisis de Construcciones")
        boton_construcciones.clicked.connect(self.activar_detector)
        layout.addWidget(boton_construcciones)

        # Separador
        separador = QFrame()
        separador.setFrameShape(QFrame.HLine)
        separador.setFrameShadow(QFrame.Sunken)
        layout.addWidget(separador)

        # Descripción y botón para el análisis de contribuciones
        layout.addWidget(QLabel("<b>Resaltar Avaluo >= 56.846.995</b>"))
        layout.addWidget(QLabel("Resalta predios cuyo Avaluo Total es mayor o igual a 56.846.995 CLP en color naranja con transparencia."))
        boton_contribuciones = QPushButton("Ejecutar Análisis de Contribuciones")
        boton_contribuciones.clicked.connect(self.pintar_avaluo)
        layout.addWidget(boton_contribuciones)

        # Establecer el layout y mostrar el diálogo
        dialog.setLayout(layout)
        dialog.exec_()

from qgis.PyQt.QtWidgets import QDockWidget, QTextEdit, QLineEdit, QPushButton, QVBoxLayout, QWidget
from qgis.PyQt.QtCore import Qt
import re

class ChatboxPlugin(QDockWidget):
    def __init__(self, iface):
        super().__init__("Chatbox de Ayuda", iface.mainWindow())
        self.iface = iface
        self.setAllowedAreas(Qt.LeftDockWidgetArea | Qt.RightDockWidgetArea)
        self.setFloating(True)
        self.setVisible(False)  # Ocultar por defecto

        # Configuración del chatbox (entrada de texto y visualización de respuesta)
        chat_widget = QWidget()
        layout = QVBoxLayout()
        
        self.query_input = QLineEdit()  # Entrada de texto para consulta
        self.query_input.setPlaceholderText("Escriba la categoría o consulta...")
        self.query_input.returnPressed.connect(self.process_query)

        self.response_display = QTextEdit()  # Área de texto para la respuesta
        self.response_display.setReadOnly(True)

        self.submit_button = QPushButton("Consultar")
        self.submit_button.clicked.connect(self.process_query)

        layout.addWidget(self.query_input)
        layout.addWidget(self.submit_button)
        layout.addWidget(self.response_display)
        
        chat_widget.setLayout(layout)
        self.setWidget(chat_widget)

    def process_query(self):
        # Obtener la consulta del usuario
        query = self.query_input.text().strip().lower()
        
        # Procesar la consulta según las categorías definidas
        response = self.get_response(query)
        
        # Mostrar la respuesta en el área de texto
        self.response_display.setText(response)

    def identify_category(self, query):
        """
        Identifica la categoría basándose en palabras clave en la consulta del usuario.
        """
        categories = {
            "ad": ["actualización", "nombre", "rut", "propietario", "dirección"],
            "aa": ["rebaja", "contribuciones", "adulto mayor"],
            "ab": ["exenciones", "sobretasa", "sitios no edificados"],
            "ac": ["certificados", "avalúo", "especiales"],
            "a": ["rol de avalúo", "saneamiento", "título"],
            "af": ["exenciones", "sobretasa", "oficio", "sitio no edificado"],
            "ag": ["cartografía", "digital", "mapas", "actualización"],
            "ah": ["carga masiva", "programa", "2890", "datos"],
            "ai": ["nómina", "municipal", "sne", "pa", "pl", "actualización"],
            "aj": ["sobretasa", "bienes inmuebles", "revisión"],
            "ak": ["información", "solicitud", "entrega", "documentación"],
            "al": ["declarativo", "municipal"],
            "am": ["inclusión", "rol de avalúo", "nuevo", "registro"],
            "an": ["solicitud", "entrega", "información"],
            "ao": ["catastro", "subdirección", "actualización", "centralizada"],
            "ap": ["carga masiva", "web service", "actualización"],
            "aq": ["patrimonio", "separado", "securitizadoras", "valores"],
            "ar": ["aerofotogrametría", "actualización", "imágenes aéreas"],
            "b": ["actualización", "avalúo fiscal", "obra nueva", "modificación", "destino", "bien raíz"],
            "c": ["revisión", "oficio", "avalúo fiscal", "actualización"],
            "d": ["número", "rol de avalúo", "trámite", "asignación"],
            "g": ["planes de fiscalización", "actuación de oficio", "plan fiscalización regional"],
            "h": ["información", "solicitud", "entrega", "consulta"],
            "i": ["siniestros", "catastrófico", "masivo", "daño"],
            "m": ["declarativo", "masivo", "municipal", "pr", "rf"],
            "p": ["reposiciones", "reavalúo", "modificación", "individual", "administrativas"],
            "q": ["tasación", "inmuebles especiales", "fiscalización", "actuación de oficio"],
            "r": ["tasaciones", "comerciales", "valor", "mercado"],
            "t": ["carga masiva", "programa", "2890", "actualización", "datos"],
            "z": ["exenciones", "sobretasa", "sitios no edificados", "modelo c", "resolución"],
        }

         # Revisar si la categoría exacta fue ingresada
        if query in categories:
            return query
        
        # Si no es exacto, buscar coincidencias de palabras clave
        for cat, keywords in categories.items():
            for keyword in keywords:
                if re.search(rf"\b{keyword}\b", query):
                    return cat
                
        return None  # Si no se encuentra coincidencia

    def get_response(self, query):
        """
        Genera una respuesta detallada según la categoría identificada o devuelve un mensaje de error.
        """
        category = self.identify_category(query)
        
        if category is None:
            return (
                "Categoría no reconocida. Por favor, intente con una consulta válida.\n\n"
                "Ejemplos de consultas válidas:\n"
                "- 'Actualizar nombre del propietario'\n"
                "- 'Rebaja de contribuciones para adulto mayor'\n"
                "- 'Exenciones y sobretasa sitios no edificados'"
            )
        
        # Generar respuesta específica según la categoría
        if category == "ad":
            return (
                "Orden de trabajo: AD\n"
                "Nombre de la orden de trabajo: Actualización de Nombre, Rut Propietario y/o Dirección del Bien Raíz\n"
                "¿Requiere visita a terreno?: No, ajustes administrativos. Solo si el cambio implica modificaciones visuales del predio.\n\n"
                "¿Requiere Informe Técnico?: No, excepto si afecta la clasificación del predio.\n\n"
                "Códigos de movimiento sugeridos:\n"
                "- 10A: Errores de transcripción y copia.\n"
                "- 16A: Cambio de nombre, dirección, predial o postal.\n"
                "- 13: Rectificación de vigencia.\n\n"
                "Acciones recomendadas: Verificar documentación y actualizar datos en el sistema."
            )
        elif category == "aa":
            return (
                "Orden de trabajo: AA\n"
                "Nombre de la orden de trabajo: Rebaja de Contribuciones para Adulto Mayor\n"
                "Condición de edad: Especificar si el propietario cumple con los requisitos de edad.\n\n"
                "¿Requiere visita a terreno?: No, basta con la verificación documental.\n\n"
                "¿Requiere Informe Técnico?: No.\n\n"
                "Códigos de movimiento sugeridos:\n"
                "- 37: Exención de impuesto territorial.\n"
                "- 62: Ajuste en exención por edad.\n\n"
                "Acciones recomendadas: Confirmar condiciones de edad y documentación."
            )
        elif category == "ab":
            return (
                "Orden de trabajo: AB\n"
                "Nombre de la orden de trabajo: Actualización de Exenciones y Sobretasa Sitios No Edificados\n"
                "Situación del sitio: Especificar si el sitio está edificado o en estado eriazo.\n\n"
                "¿Requiere visita a terreno?: Sí, si es necesario verificar el estado físico.\n\n"
                "¿Requiere Informe Técnico?: Sí, para la clasificación del sitio.\n\n"
                "Códigos de movimiento sugeridos:\n"
                "- 08: Tasación sobretasa 100%.\n"
                "- 10D: Cambio de serie y destino.\n"
                "- 12A: Nuevas construcciones (si aplica).\n\n"
                "Acciones recomendadas: Inspeccionar el predio y actualizar los registros catastrales."
            )
        elif category == "ac":
            return (
                "Orden de trabajo: AC\n"
                "Nombre de la orden de trabajo: Certificados de Avalúo Especiales\n"
                "Tipo de certificado: Concesiones, avalúos especiales, etc.\n\n"
                "¿Requiere visita a terreno?: No, salvo para avalúos detallados.\n\n"
                "¿Requiere Informe Técnico?: Sí, especialmente en infraestructuras marítimas o concesiones.\n\n"
                "Códigos de movimiento sugeridos:\n"
                "- 27M: Concesiones marítimas.\n"
                "- 27L: Concesiones de infraestructura.\n\n"
                "Acciones recomendadas: Emitir certificado basado en análisis técnico."
            )
        elif category == "a":
            return (
                "Orden de trabajo: A\n"
                "Nombre de la orden de trabajo: Asignación de número de Rol de Avalúo a Saneamiento de Título\n"
                "Estado del título: Especificar si está saneado o en trámite.\n\n"
                "¿Requiere visita a terreno?: Sí, para verificar los límites físicos.\n\n"
                "¿Requiere Informe Técnico?: Sí, para validar el estado del título.\n\n"
                "Códigos de movimiento sugeridos:\n"
                "- 15: Avalúo parcial edil.\n"
                "- 10C: Errores de clasificación.\n"
                "- 13: Rectificación de vigencia.\n\n"
                "Acciones recomendadas: Inspección de campo y validación de documentación."
            )
        elif category == "af":
            return (
                "Orden de trabajo: AF\n"
                "Nombre de la orden de trabajo: Exenciones y Sobretasa Sitios No Edificados\n"
                "Estado del sitio: Especificar si es edificado o eriazo.\n\n"
                "¿Requiere visita a terreno?: Sí, en caso de necesitar verificar el estado físico.\n\n"
                "¿Requiere Informe Técnico?: Sí, para clasificar el estado del sitio.\n\n"
                "Códigos de movimiento sugeridos:\n"
                "- 10D: Cambio de serie y destino.\n"
                "- 12A: Nuevas construcciones.\n"
                "- 12B: Ampliaciones y reparaciones.\n\n"
                "Acciones recomendadas: Inspección y actualización de registros."
            )
        elif category == "ag":
            return (
                "Orden de trabajo: AG\n"
                "Nombre de la orden de trabajo: Actualización Cartografía Digital SII Mapas\n"
                "Tipo de actualización: Especificar tipo de actualización requerida.\n\n"
                "¿Requiere visita a terreno?: No, generalmente es una actualización digital.\n\n"
                "¿Requiere Informe Técnico?: No.\n\n"
                "Códigos de movimiento sugeridos:\n"
                "- 16C: División de avalúo.\n"
                "- 16B: Inclusión de predios omitidos.\n"
                "- 16E: Fusión de roles.\n\n"
                "Acciones recomendadas: Ejecutar la actualización en el sistema de cartografía digital."
            )
        elif category == "ah":
            return (
                "Orden de trabajo: AH\n"
                "Nombre de la orden de trabajo: Programa de carga masiva 2890\n"
                "¿Requiere visita a terreno?: No, se realiza digitalmente.\n\n"
                "¿Requiere Informe Técnico?: No.\n\n"
                "Códigos de movimiento sugeridos:\n"
                "- 13: Rectificación de vigencia.\n"
                "- 15: Avalúo parcial edil.\n"
                "- 16A: Cambio de nombre o dirección.\n\n"
                "Acciones recomendadas: Cargar los datos masivos en el sistema."
            )
        elif category == "ai":
            return (
                "Orden de trabajo: AI\n"
                "Nombre de la orden de trabajo: Nómina Municipal SNE/PA/PL\n"
                "¿Requiere visita a terreno?: No, generalmente es administrativo.\n\n"
                "¿Requiere Informe Técnico?: No.\n\n"
                "Códigos de movimiento sugeridos:\n"
                "- 10F: Omisión de bienes.\n"
                "- 13: Rectificación de vigencia.\n"
                "- 16F: División de avalúo.\n\n"
                "Acciones recomendadas: Actualizar la nómina municipal."
            )
        elif category == "aj":
            return (
                "Orden de trabajo: AJ\n"
                "Nombre de la orden de trabajo: Revisión de Sobretasa Bienes Inmuebles\n"
                "Estado del inmueble: Especificar si es sitio eriazo o edificado.\n\n"
                "¿Requiere visita a terreno?: Sí, para verificar el uso actual.\n\n"
                "¿Requiere Informe Técnico?: Sí, para definir la sobretasa.\n\n"
                "Códigos de movimiento sugeridos:\n"
                "- 08: Tasación sobretasa 100%.\n"
                "- 11A: Tasación de casas patronales.\n"
                "- 12D: Nuevas obras de urbanización.\n\n"
                "Acciones recomendadas: Verificar el uso actual y ajustar la sobretasa."
            )
        elif category == "ak":
            return (
                "Orden de trabajo: AK\n"
                "Nombre de la orden de trabajo: Solicitud/Entrega de Información\n"
                "¿Requiere visita a terreno?: No, solo se requiere la gestión de información.\n\n"
                "¿Requiere Informe Técnico?: No.\n\n"
                "Códigos de movimiento sugeridos:\n"
                "- 13: Rectificación de vigencia.\n"
                "- 16A: Cambio de nombre o dirección.\n"
                "- 37: Solicitud de información.\n\n"
                "Acciones recomendadas: Gestionar solicitud y actualizar el registro de entrega."
            )
        elif category == "al":
            return (
                "Orden de trabajo: AL\n"
                "Nombre de la orden de trabajo: Declarativo Municipal\n"
                "¿Requiere visita a terreno?: No, es un proceso administrativo.\n\n"
                "¿Requiere Informe Técnico?: No.\n\n"
                "Códigos de movimiento sugeridos:\n"
                "- 11A: Tasación de casas patronales.\n"
                "- 15: Avalúo parcial edil.\n"
                "- 27M: Concesiones marítimas.\n\n"
                "Acciones recomendadas: Procesar el declarativo y verificar datos."
            )
        elif category == "am":
            return (
                "Orden de trabajo: AM\n"
                "Nombre de la orden de trabajo: Inclusión Rol de Avalúo\n"
                "¿Requiere visita a terreno?: No, salvo excepciones donde se requiera verificación física.\n\n"
                "¿Requiere Informe Técnico?: No.\n\n"
                "Códigos de movimiento sugeridos:\n"
                "- 16B: Inclusión de predios omitidos.\n"
                "- 12A: Nuevas construcciones.\n"
                "- 10F: Omisión de bienes.\n\n"
                "Acciones recomendadas: Incluir el nuevo rol de avalúo y ajustar datos catastrales."
            )
        elif category == "an":
            return (
                "Orden de trabajo: AN\n"
                "Nombre de la orden de trabajo: Solicitud/Entrega de Información\n"
                "¿Requiere visita a terreno?: No, solo es necesario gestionar la solicitud de información.\n\n"
                "¿Requiere Informe Técnico?: No.\n\n"
                "Códigos de movimiento sugeridos:\n"
                "- 37: Solicitud de información.\n"
                "- 62: Entrega de información.\n"
                "- 16A: Cambio de nombre o dirección.\n\n"
                "Acciones recomendadas: Responder la solicitud y registrar entrega de información."
            )
        elif category == "ao":
            return (
                "Orden de trabajo: AO\n"
                "Nombre de la orden de trabajo: Actualización Centralizada del Catastro Subdirección\n"
                "¿Requiere visita a terreno?: No, es una actualización de sistema centralizada.\n\n"
                "¿Requiere Informe Técnico?: No.\n\n"
                "Códigos de movimiento sugeridos:\n"
                "- 13: Rectificación de vigencia.\n"
                "- 16B: Inclusión predios omitidos.\n"
                "- 15: Avalúo parcial edil.\n\n"
                "Acciones recomendadas: Procesar actualización en el sistema para mantener vigencia de datos."
            )
        elif category == "ap":
            return (
                "Orden de trabajo: AP\n"
                "Nombre de la orden de trabajo: Actualización Masiva F2890 por Web Service\n"
                "¿Requiere visita a terreno?: No, es un proceso en línea.\n\n"
                "¿Requiere Informe Técnico?: No.\n\n"
                "Códigos de movimiento sugeridos:\n"
                "- 13: Rectificación de vigencia.\n"
                "- 10A: Errores de transcripción y copia.\n"
                "- 15: Avalúo parcial edil.\n\n"
                "Acciones recomendadas: Verificar que los datos masivos se procesen correctamente."
            )
        elif category == "aq":
            return (
                "Orden de trabajo: AQ\n"
                "Nombre de la orden de trabajo: Patrimonio Separado Securitizadoras\n"
                "¿Requiere visita a terreno?: No, se realiza sobre registros administrativos.\n\n"
                "¿Requiere Informe Técnico?: No.\n\n"
                "Códigos de movimiento sugeridos:\n"
                "- 16B: Inclusión de predios omitidos.\n"
                "- 13: Rectificación de vigencia.\n"
                "- 16C: Fusión de roles.\n\n"
                "Acciones recomendadas: Registrar información de patrimonio separado y ajustar catastro."
            )
        elif category == "ar":
            return (
                "Orden de trabajo: AR\n"
                "Nombre de la orden de trabajo: Actualización por Aerofotogrametría\n"
                "¿Requiere visita a terreno?: No, se basa en imágenes aéreas.\n\n"
                "¿Requiere Informe Técnico?: Sí, las imágenes aéreas requieren interpretación.\n\n"
                "Códigos de movimiento sugeridos:\n"
                "- 12B: Ampliaciones, reparaciones.\n"
                "- 12A: Nuevas construcciones.\n"
                "- 10C: Errores de clasificación.\n\n"
                "Acciones recomendadas: Revisar información de aerofotogrametría y actualizar el catastro."
            )
        elif category == "b":
            return (
                "Orden de trabajo: B\n"
                "Nombre de la orden de trabajo: Actualización de Avalúo Fiscal, Actuación de oficio\n"
                "¿Requiere visita a terreno?: Sí, para verificar características físicas.\n\n"
                "¿Requiere Informe Técnico?: Sí, para determinar el valor fiscal.\n\n"
                "Códigos de movimiento sugeridos:\n"
                "- 10A: Errores de transcripción y copia.\n"
                "- 12A: Nuevas construcciones.\n"
                "- 10D: Cambio de serie y destino.\n\n"
                "Acciones recomendadas: Evaluación física y actualización del registro catastral."
            )
        elif category == "c":
            return (
                "Orden de trabajo: C\n"
                "Nombre de la orden de trabajo: Actualización de Avalúo Fiscal y Actuación de oficio\n"
                "¿Requiere visita a terreno?: No, basado en revisión de datos.\n\n"
                "¿Requiere Informe Técnico?: Sí, para evaluar posibles discrepancias.\n\n"
                "Códigos de movimiento sugeridos:\n"
                "- 10A: Errores de transcripción y copia.\n"
                "- 16A: Cambio de nombre o dirección.\n"
                "- 13: Rectificación de vigencia.\n\n"
                "Acciones recomendadas: Revisar documentos de registro y confirmar precisión de datos."
            )
        elif category == "d":
            return (
                "Orden de trabajo: D\n"
                "Nombre de la orden de trabajo: Asignación de Número de Rol de Avalúo en Trámite\n"
                "¿Requiere visita a terreno?: No, es un procedimiento administrativo.\n\n"
                "¿Requiere Informe Técnico?: No.\n\n"
                "Códigos de movimiento sugeridos:\n"
                "- 16A: Cambio de nombre o dirección.\n"
                "- 35A: Cambio de nombre.\n"
                "- 35D: Eliminación de roles.\n\n"
                "Acciones recomendadas: Asignar el nuevo rol y verificar registro."
            )
        elif category == "g":
            return (
                "Orden de trabajo: G\n"
                "Nombre de la orden de trabajo: Planes de fiscalización y Actuación de Oficio\n"
                "¿Requiere visita a terreno?: Sí, para verificar condiciones del bien.\n\n"
                "¿Requiere Informe Técnico?: Sí, para documentar estado actual del bien.\n\n"
                "Códigos de movimiento sugeridos:\n"
                "- 10D: Cambio de serie y destino.\n"
                "- 28E: Siniestros.\n"
                "- 37: Eliminación por fallo.\n\n"
                "Acciones recomendadas: Visitar el predio y ajustar registros en base al informe técnico."
            )
        elif category == "h":
            return (
                "Orden de trabajo: H\n"
                "Nombre de la orden de trabajo: Solicitud/Entrega de información\n"
                "¿Requiere visita a terreno?: No.\n\n"
                "¿Requiere Informe Técnico?: No.\n\n"
                "Códigos de movimiento sugeridos:\n"
                "- 37: Solicitud de información.\n"
                "- 62: Consulta de datos.\n"
                "- 2A: Otorga exención.\n\n"
                "Acciones recomendadas: Revisar datos y proporcionar la información solicitada."
            )
        elif category == "i":
            return (
                "Orden de trabajo: I\n"
                "Nombre de la orden de trabajo: Siniestros de carácter masivo y catastrófico\n"
                "¿Requiere visita a terreno?: Sí, para evaluar el daño.\n\n"
                "¿Requiere Informe Técnico?: Sí, para documentar alcance del daño.\n\n"
                "Códigos de movimiento sugeridos:\n"
                "- 12C: Demolición total o parcial.\n"
                "- 28E: Siniestros.\n"
                "- 2H: Exención habitacional.\n\n"
                "Acciones recomendadas: Inspeccionar el sitio y actualizar registros tras el siniestro."
            )
        elif category == "m":
            return (
                "Orden de trabajo: M\n"
                "Nombre de la orden de trabajo: Declarativo masivo municipal (PR, RF)\n"
                "¿Requiere visita a terreno?: No, es administrativo.\n\n"
                "¿Requiere Informe Técnico?: No.\n\n"
                "Códigos de movimiento sugeridos:\n"
                "- 13: Rectificación de vigencia.\n"
                "- 37: Solicitud de información.\n"
                "- 16A: Cambio de nombre o dirección.\n\n"
                "Acciones recomendadas: Actualizar datos según procedimiento masivo."
            )
        elif category == "p":
            return (
                "Orden de trabajo: P\n"
                "Nombre de la orden de trabajo: Reposiciones Administrativas por Reavalúo y por Modificación Individual\n"
                "¿Requiere visita a terreno?: No en todos los casos.\n\n"
                "¿Requiere Informe Técnico?: Sí, para justificar reposición.\n\n"
                "Códigos de movimiento sugeridos:\n"
                "- 10D: Cambio de serie y destino.\n"
                "- 11A: Tasación de casas patronales.\n"
                "- 13: Rectificación de vigencia.\n\n"
                "Acciones recomendadas: Análisis detallado y ajuste de avalúo."
            )
        elif category == "q":
            return (
                "Orden de trabajo: Q\n"
                "Nombre de la orden de trabajo: Tasación de Inmuebles de Características Especiales\n"
                "¿Requiere visita a terreno?: Sí, para verificar características especiales.\n\n"
                "¿Requiere Informe Técnico?: Sí.\n\n"
                "Códigos de movimiento sugeridos:\n"
                "- 28E: Siniestros.\n"
                "- 2A: Otorga exención.\n"
                "- 70: Eliminación de concesión.\n\n"
                "Acciones recomendadas: Documentar características específicas y ajustar registros."
            )
        elif category == "r":
            return (
                "Orden de trabajo: R\n"
                "Nombre de la orden de trabajo: Tasaciones Comerciales\n"
                "¿Requiere visita a terreno?: Sí, se requiere un análisis detallado.\n\n"
                "¿Requiere Informe Técnico?: Sí, para justificar el valor comercial.\n\n"
                "Códigos de movimiento sugeridos:\n"
                "- 35A: Cambio de nombre.\n"
                "- 10C: Errores de clasificación.\n"
                "- 37: Eliminación por fallo.\n\n"
                "Acciones recomendadas: Inspección del inmueble y análisis de mercado."
            )
        elif category == "t":
            return (
                "Orden de trabajo: T\n"
                "Nombre de la orden de trabajo: Programa de carga masiva 2890\n"
                "¿Requiere visita a terreno?: No.\n\n"
                "¿Requiere Informe Técnico?: No.\n\n"
                "Códigos de movimiento sugeridos:\n"
                "- 37: Solicitud de información.\n"
                "- 62: Consulta de datos.\n"
                "- 13: Rectificación de vigencia.\n\n"
                "Acciones recomendadas: Completar la carga masiva en el sistema."
            )
        elif category == "z":
            return (
                "Orden de trabajo: Z\n"
                "Nombre de la orden de trabajo: Actualización de Exenciones y Sobretasa Sitios No Edificados\n"
                "¿Requiere visita a terreno?: No, a menos que haya discrepancias en el registro.\n\n"
                "¿Requiere Informe Técnico?: Sí.\n\n"
                "Códigos de movimiento sugeridos:\n"
                "- 12A: Nuevas construcciones.\n"
                "- 10D: Cambio de serie y destino.\n"
                "- 11B: Alteración de uso del suelo.\n\n"
                "Acciones recomendadas: Revisar documentación y emitir informe técnico."
            )
        else:
            return "Categoría no reconocida o no registrada."

# Inicializar el plugin en QGIS
def classFactory(iface):
    return ChatboxPlugin(iface)
